package com.wang.emqxpublish.emqxpublish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmqxpublishApplicationTests {

    @Test
    void contextLoads() {
    }

}
