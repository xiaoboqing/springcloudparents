package com.wang.emqxpublish.emqxpublish;

import com.wang.emqxpublish.emqxpublish.mqtt.MqttPushClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

/**
 * 发布消息
 */
@SpringBootApplication
public class EmqxpublishApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmqxpublishApplication.class, args);
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                try {
                    test();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        },0,20 * 1000);

    }
    private static void test(){

        MqttPushClient.MQTT_HOST = "tcp://47.111.252.79:1883";
        String topic = "notify/123"; // 主题
        MqttPushClient.MQTT_CLIENTID = "60582145987";  // 客户端id
        MqttPushClient.MQTT_USERNAME = "admin";
        MqttPushClient.MQTT_PASSWORD = "public";
        Map<String, String> map = new HashMap<>();

        map.put("name","tom");
        map.put("age", "18");
        map.put("address", "shanghai");
//        JSONObject jsonMap = JSONObject.fromObject(map);
        MqttPushClient client = MqttPushClient.getInstance();
         //
        client.publish(topic, map.toString());
    }
}
