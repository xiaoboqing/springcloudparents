package com.wang.emqx;

import com.wang.emqx.mqtt.MqttPushClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Timer;
import java.util.TimerTask;

/**
 * 订阅消息
 */
@SpringBootApplication
public class EmqxApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmqxApplication.class, args);


    test();
    }

    private static void test(){
        System.out.println("............");
        String topic = "notify/123";  // 主题
        String clientid = String.valueOf(System.currentTimeMillis());
        MqttPushClient.MQTT_HOST = "tcp://47.111.252.79:1883";
        MqttPushClient.MQTT_CLIENTID = clientid; // 客户端id
        MqttPushClient.MQTT_USERNAME = "admin";
        MqttPushClient.MQTT_PASSWORD = "public";

        MqttPushClient client = MqttPushClient.getInstance();
        client.subscribe(topic);  // 调用订阅方法
    }
}
